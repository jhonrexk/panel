<?php

namespace Cloudflare\Exception;

class UnauthorizedException extends \RuntimeException
{
}
